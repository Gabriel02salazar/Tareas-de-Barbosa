/*
 * leds.h
 *
 * Created: 2/27/2024 6:51:29 PM
 *  Author: josel
 */ 


#ifndef LEDS_H_
#define LEDS_H_
void led_on_off (void);

#endif /* LEDS_H_ */