/*
 * ports.h
 *
 * Created: 2/27/2024 6:35:38 PM
 *  Author: jlb
 */ 


#ifndef PORTS_H_
#define PORTS_H_
void init_ports(void);

#endif /* PORTS_H_ */