﻿/*
 * ext_int.h
 *
 * Created: 12/03/2024 07:07:39 a. m.
 *  Author: jlb
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_
void init_ext_int(void);

#endif /* INT_EXT_H_ */