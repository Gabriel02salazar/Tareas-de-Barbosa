/*
 * comp.h
 *
 * Created: 9/20/2023 4:19:07 PM
 *  Author: josel
 */ 


#ifndef COMP_H_
#define COMP_H_
void init_analog_comp(void);

#endif /* COMP_H_ */